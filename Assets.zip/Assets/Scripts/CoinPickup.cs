using Unity.Cinemachine;
using UnityEngine;

public class CoinPickup : MonoBehaviour
{
    [SerializeField] int value = 10;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            Object.FindFirstObjectByType<GameSession>().increaseScore(value);
            Destroy(gameObject);
        }
    }
}
