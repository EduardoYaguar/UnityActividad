using TMPro;
using UnityEngine;

public class GameSession : MonoBehaviour
{

    [SerializeField] int playerScore = 0;

    [SerializeField] TextMeshProUGUI scoreText;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
        scoreText.text = playerScore.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void increaseScore(int pointsAdd)
    {
        playerScore += pointsAdd;
        scoreText.text = playerScore.ToString();
    }
}
